package com.tugas3;

abstract class BangunDatar {
    public abstract double getLuas();
    public abstract double getKeliling();
}